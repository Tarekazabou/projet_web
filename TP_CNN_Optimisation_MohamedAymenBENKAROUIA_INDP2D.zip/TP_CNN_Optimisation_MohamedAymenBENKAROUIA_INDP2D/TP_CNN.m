% --- Explication de l'objectif : ce code sert a classifier
% un nuage de points en deux classes : 1 et 2. Pour ce faire, Ce code crée un réseau
% de neurones (2 entrées, 3 neurones cachés, 2 sorties), puis il entraîne 
% ce réseau à partir d’un ensemble de données aléatoires pour ajuster ses 
% poids et ses biais afin de séparer deux classes.le resultat est une 
% classification du nuage avec une efficacité entre 98% et 100%.
% MATLAB crée le réseau avec :
% des poids et biais initiaux aléatoires,
% une structure avec 2 entrées → 3 neurones cachés → 2 neurones de sortie,
% des fonctions d’activation sigmoïdes (logsig) par défaut.
% Pendant l’appel à train(net, X, Y), MATLAB fait :
% une propagation avant pour calculer la sortie du réseau,
% une comparaison avec la sortie désirée (Y),
% puis un ajustement des poids et biais à l’aide de l’algorithme de descente de gradient (ici traingd).
% Ce processus se répète sur plusieurs époques jusqu’à ce que l’erreur diminue.







% LE CODE :
% --- Generate synthetic 2D data for 2 classes ---

% Class 1: centered near (0,0)
class1 = randn(2,100) * 0.3;

% Class 2: centered near (1,1)
class2 = randn(2,100) * 0.3 + 1;

% Combine data
X = [class1 class2];
Y = [repmat([1;0],1,100) repmat([0;1],1,100)];  % one-hot encoding

% --- Define neural network: 2 inputs, 3 hidden neurons, 2 outputs ---
net = patternnet(3);

% Training parameters
net.trainFcn = 'traingd';        % Gradient descent
net.trainParam.lr = 0.1;         % Learning rate
net.trainParam.epochs = 1000;    % Number of training iterations

% --- Train the network ---
net = train(net, X, Y);

% --- Test the network ---
Y_pred = net(X);
[~, pred_class] = max(Y_pred);    % predicted class (1 or 2)
[~, true_class] = max(Y);         % true class

% --- Compute accuracy ---
accuracy = sum(pred_class == true_class) / numel(true_class);
fprintf('Classification accuracy: %.2f%%\n', accuracy*100);

% --- Visualization of classification result ---
figure;
gscatter(X(1,:), X(2,:), true_class, 'rb', 'xo');
hold on;
plot(X(1,pred_class~=true_class), X(2,pred_class~=true_class), 'ks', 'MarkerSize', 10);
title('2-Class Classification (2-3-2 Neural Network)');
xlabel('x1'); ylabel('x2');
legend('Class 1','Class 2','Misclassified');
